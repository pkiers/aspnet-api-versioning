﻿using Microsoft.Web.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace WebApiVersionExample.Controllers
{
    //[ApiVersion( "2.0" )]
    [ApiVersions( "2.0", "4.0" )]
    [RoutePrefix( "api/v{version:apiVersion}/tfmemployee" )]
    public class TfmEmployee2Controller : ApiController
    {
        [Route]
        public IHttpActionResult Get() => Ok( $"Success (from {GetType().Name})" );
    }
}