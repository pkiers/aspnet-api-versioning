﻿using Microsoft.Web.Http.Versioning;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiVersionExample
{
    [AttributeUsage( AttributeTargets.Class, AllowMultiple = true, Inherited = false )]
    public sealed class ApiVersionsAttribute : ApiVersionsBaseAttribute, IApiVersionProvider
    {
        public ApiVersionsAttribute( params string[] versions ) : base( versions ) { }

        bool IApiVersionProvider.AdvertiseOnly => false;

        public bool Deprecated { get; set; }
    }
}