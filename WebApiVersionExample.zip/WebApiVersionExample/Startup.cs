﻿using Microsoft.Owin;
using Microsoft.Web.Http.Routing;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Routing;
using WebApiVersionExample;

[assembly: OwinStartup( typeof( Startup ) )]

namespace WebApiVersionExample
{
    public class Startup
    {
        public void Configuration( IAppBuilder app )
        {
            var constraintResolver = new DefaultInlineConstraintResolver() { ConstraintMap = { ["apiVersion"] = typeof( ApiVersionRouteConstraint ) } };
            var config = new HttpConfiguration();
            config.MapHttpAttributeRoutes( constraintResolver );
            config.AddApiVersioning();
            app.UseWebApi( config );
        }
    }
}