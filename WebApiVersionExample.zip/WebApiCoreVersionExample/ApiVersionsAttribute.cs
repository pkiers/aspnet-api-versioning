﻿using Microsoft.AspNetCore.Mvc.Versioning;
using System;

namespace WebApiCoreVersionExample
{
    [AttributeUsage( AttributeTargets.Class, AllowMultiple = true, Inherited = false )]
    public sealed class ApiVersionsAttribute : ApiVersionsBaseAttribute, IApiVersionProvider
    {
        public ApiVersionsAttribute( params string[] versions ) : base( versions ) { }

        bool IApiVersionProvider.AdvertiseOnly => false;

        public bool Deprecated { get; set; }
    }
}