﻿using Microsoft.AspNetCore.Mvc;
using WebApiCoreVersionExample;

namespace WebApiVersionExample.Controllers
{
    //[ApiVersion( "2.0" )]
    [ApiVersions( "2.0", "4.0" )]
    [Route( "api/v{version:apiVersion}/tfmemployee" )]
    public class TfmEmployee2Controller : Controller
    {
        [Route("")]
        public ObjectResult Get() => Ok($"Success (from {GetType().Name})");
    }
}