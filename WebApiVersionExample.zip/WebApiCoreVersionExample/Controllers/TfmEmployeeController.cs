﻿using Microsoft.AspNetCore.Mvc;
using WebApiCoreVersionExample;

namespace WebApiVersionExample.Controllers
{
    //[ApiVersion( "1.0" )]
    [ApiVersions( "1.0", "3.0" )]
    [Route( "api/v{version:apiVersion}/tfmemployee" )]
    public class TfmEmployeeController : Controller
    {
        [Route("")]
        public ObjectResult Get() => Ok( $"Success (from {GetType().Name})" );
    }
}